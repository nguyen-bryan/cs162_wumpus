/************************************
** Program: gold.cpp
** Author: Bryan Nguyen
** Date: 05/23/2021
** Description: Gold Implementation
** Input: None
** Output: None
*************************************/

#include <iostream>
#include "event.h"
#include "gold.h"

using namespace std;

/************************************
** Function: Gold constructor
** Description: construction of gold
** Parameters: None
** Pre-conditions: creation of gold
** Post-conditions: gold is created
*************************************/
Gold::Gold(){
    name = "Gold";

}

/************************************
** Function: Gold deconstructor
** Description: deconstruction of gold
** Parameters: None
** Pre-conditions: decreation of gold
** Post-conditions: gold is destroyed
*************************************/
Gold::~Gold(){

}

/************************************
** Function: percept()
** Description: gold percept
** Parameters: None
** Pre-conditions: percept called
** Post-conditions: returns message
*************************************/
string Gold::percept(){
    string temp = "You see a glimmer nearby";
    return temp;
    
}

/************************************
** Function: event()
** Description: gold event
** Parameters: None
** Pre-conditions: event called
** Post-conditions: returns message
*************************************/
string Gold::event(){
    string temp = "You pick up a pile of gold";
    return temp;
    
}