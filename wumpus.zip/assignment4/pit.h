/************************************
** Program: pit.h
** Author: Bryan Nguyen
** Date: 05/23/2021
** Description: Pit Header
** Input: None
** Output: None
*************************************/

#ifndef pit_h
#define pit_h

#include <iostream>
#include "event.h"

using namespace std;

class Pit : public Event{ 
    private:

    public:
        Pit();
        ~Pit();
        string percept();
        string event();
       
};

#endif
