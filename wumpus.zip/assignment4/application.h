/************************************
** Program: application.h
** Author: Bryan Nguyen
** Date: 05/23/2021
** Description: Application Header
** Input: None
** Output: None
*************************************/

#ifndef application_h
#define application_h
#include <vector>
#include <iostream>
#include <stdlib.h>
#include <vector>
#include "event.h"
#include "room.h"
#include "wumpus.h"
#include "bats.h"
#include "pit.h"
#include "gold.h"

//using namespace std;
using std::cout;
using std::endl;

void dead_wumpus(vector<vector<Room>> &cave);
void move_wumpus(vector<vector<Room>> &cave);
void fire_arrow(vector<vector<Room>> &cave, int pos_x, int pos_y, int x, int y);
void fire_arrow_side(vector<vector<Room>> &cave, int pos_x, int pos_y, int x, int y);
void move(vector<vector<Room>> &cave, int &pos_x, int &pos_y, int &arrow);
void set_bats(vector<vector<Room>> &cave);
void set_pit(vector<vector<Room>> &cave);
void set_wumpus(vector<vector<Room>> &cave);
void set_gold(vector<vector<Room>> &cave);
void set_cave(vector<vector<Room>> &cave, int pos_x, int pos_y);
void print_debug_cave(vector<vector<Room>> &cave, int size, int pos_x, int pos_y);
void print_percept(Event &temp);
void bat_percept(vector<vector<Room>> &cave, int &pos_x, int &pos_y);
void pit_percept(vector<vector<Room>> &cave, int &pos_x, int &pos_y);
void wumpus_percept(vector<vector<Room>> &cave, int &pos_x, int &pos_y);
void gold_percept(vector<vector<Room>> &cave, int &pos_x, int &pos_y);
void percept(vector<vector<Room>> &cave, int &pos_x, int &pos_y);
void print_event(Event &temp);
int encounter(vector<vector<Room>> &cave, int &pos_x, int &pos_y, int gold);
void print_cave(vector<vector<Room>> &cave, int size, int &pos_x, int &pos_y);
void reset_cave(vector<vector<Room>> &cave, int &gold, int &pos_x, int &pos_y);
void new_cave(vector<vector<Room>> &cave, int &gold, int &pos_x, int &pos_y);
int game_over();
void debug_mode(int size);
void game_mode(int size);
void ai_mode(int size);
void ai_move(vector<vector<Room>> &cave, int &pos_x, int &pos_y, int &arrow);

#endif