/************************************
** Program: bats.h
** Author: Bryan Nguyen
** Date: 05/23/2021
** Description: Bats Header
** Input: None
** Output: None
*************************************/
#ifndef bats_h
#define bats_h

#include <iostream>
#include "event.h"

using namespace std;

class Bats : public Event{ 
    private:

    public:
        Bats();
        ~Bats();
        string percept();
        string event();
       
};

#endif
