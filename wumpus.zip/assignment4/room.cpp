/************************************
** Program: room.cpp
** Author: Bryan Nguyen
** Date: 05/23/2021
** Description: Room Implementation
** Input: None
** Output: None
*************************************/

#include <iostream>
#include "event.h"
#include "room.h"

using namespace std;

/************************************
** Function: Room constructor
** Description: construction of room
** Parameters: None
** Pre-conditions: creation of room
** Post-conditions: room is created
*************************************/
Room::Room(){
    name = "Empty";

}

/************************************
** Function: Room deconstructor
** Description: deconstruction of room
** Parameters: None
** Pre-conditions: decreation of room
** Post-conditions: room is destroyed
*************************************/
Room::~Room(){

}
