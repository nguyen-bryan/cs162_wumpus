/************************************
** Program: gold.h
** Author: Bryan Nguyen
** Date: 05/23/2021
** Description: Gold Header
** Input: None
** Output: None
*************************************/

#ifndef gold_h
#define gold_h

#include <iostream>
#include "event.h"

using namespace std;

class Gold : public Event{ 
    private:

    public:
        Gold();
        ~Gold();
        string event();
        string percept();
       
};

#endif
