/************************************
** Program: pit.cpp
** Author: Bryan Nguyen
** Date: 05/23/2021
** Description: Pit Implementation
** Input: None
** Output: None
*************************************/

#include <iostream>
#include "event.h"
#include "pit.h"

using namespace std;

/************************************
** Function: Pit constructor
** Description: construction of pit
** Parameters: None
** Pre-conditions: creation of pit
** Post-conditions: pit is created
*************************************/
Pit::Pit(){
    name = "Pit";
}

/************************************
** Function: Pit deconstructor
** Description: deconstruction of room
** Parameters: None
** Pre-conditions: decreation of pit
** Post-conditions: room is destroyed
*************************************/
Pit::~Pit(){

}

/************************************
** Function: percept()
** Description: pit percept
** Parameters: None
** Pre-conditions: percept called
** Post-conditions: returns message
*************************************/
string Pit::percept(){
    string temp = "You feel a breeze";
    return temp;
    
}

/************************************
** Function: event()
** Description: pit event
** Parameters: None
** Pre-conditions: event called
** Post-conditions: returns message
*************************************/
string Pit::event(){
    string temp = "You have fallen into a deadly pit";
    return temp;
    
}