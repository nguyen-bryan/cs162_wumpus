/************************************
** Program: event.cpp
** Author: Bryan Nguyen
** Date: 05/23/2021
** Description: Event Implementation
** Input: None
** Output: None
*************************************/

#include <iostream>
#include "event.h"

using namespace std;

/************************************
** Function: Event constructor
** Description: construction of event
** Parameters: None
** Pre-conditions: creation of event
** Post-conditions: event is created
*************************************/
Event::Event(){
    name = "Empty";

}

/************************************
** Function: Event deconstructor
** Description: deconstruction of event
** Parameters: None
** Pre-conditions: decreation of event
** Post-conditions: event is destroyed
*************************************/
Event::~Event(){

}
