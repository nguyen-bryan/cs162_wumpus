/************************************
** Program: event.h
** Author: Bryan Nguyen
** Date: 05/23/2021
** Description: Event Header
** Input: None
** Output: None
*************************************/

#ifndef event_h
#define event_h

#include <iostream>

using namespace std;

class Event{ 
    private:

    public:
        string name;        
        
        Event();
        ~Event();
        virtual string percept() = 0;
        virtual string event() = 0;
};

#endif
