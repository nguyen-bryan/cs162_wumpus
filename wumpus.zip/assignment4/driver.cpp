/************************************
** Program: driver.cpp
** Author: Bryan Nguyen
** Date: 05/23/2021
** Description: Main Implementation
** Input: None
** Output: None
*************************************/

#include <vector>
#include <iostream>
#include <stdlib.h>
#include <vector>
#include "event.h"
#include "room.h"
#include "wumpus.h"
#include "bats.h"
#include "pit.h"
#include "gold.h"
#include "application.h"

//using namespace std;
using std::cout;
using std::endl;


int main(int argc, char *argv[]){
    int size = atoi(argv[1]);
    string temp = argv[2];
    if (temp == "true"){ // debug mode
        debug_mode(size);
    }
    else if(temp == "ai"){ //ai mode
        ai_mode(size);
    }
    else{               //normal mode
        game_mode(size);
    }
}