/************************************
** Program: applicaiton.cpp
** Author: Bryan Nguyen
** Date: 04/10/2021
** Description: Application file
** Input: 
** Output: 
*************************************/
#include <vector>
#include <iostream>
#include <stdlib.h>
#include <vector>
#include "event.h"
#include "room.h"
#include "wumpus.h"
#include "bats.h"
#include "pit.h"
#include "gold.h"
#include "application.h"

using std::cout;
using std::endl;

/************************************
** Function: dead_wumpus
** Description: kills the wumpus
** Parameters: cave
** Pre-conditions: cave exists
** Post-conditions: wumpus declared dead
*************************************/
void dead_wumpus(vector<vector<Room>> &cave){
    for (int i =0; i < cave.size(); i++){
        for (int j = 0; j < cave.size(); j++){
            if(cave[i][j].name == "Wumpus"){
                cave[i][j].name = "Dead";
            }
        }
    }
}

/************************************
** Function: move_wumpus
** Description: moves the wumpus
** Parameters: cave
** Pre-conditions: cave exists
** Post-conditions: wumpus is moved
*************************************/
void move_wumpus(vector<vector<Room>> &cave){
    cout << "The Wumpus has moved" << endl;
    for (int i =0; i < cave.size(); i++){
        for(int j = 0; j < cave.size(); j++){
            if(cave[i][j].name == "Wumpus"){
                cave[i][j].name = "Moved";
            }
        }
    }
    set_wumpus(cave);
}

/************************************
** Function: fire_arrow
** Description: fires an arrow on the vertical axis
** Parameters: cave, pos_x, pos_y, x, y
** Pre-conditions: all parameters exist
** Post-conditions: arrow is fired, killing/moving wumpus
*************************************/
// This function is over 20 lines (43), it all repeats the same code with minor differences
// This function could be seperated into 2, but this function is already seperated from the other arrow function
// and it wouldn't make sense to continue seperating the code only to keep the functions shorter

void fire_arrow(vector<vector<Room>> &cave, int pos_x, int pos_y, int x, int y){
    int move = rand() % 4;
    cout << "You fire an arrow" << endl;
    if(x == -1 && pos_x - 3 >= 0){
        if(cave[pos_x -1][pos_y].name == "Wumpus" || cave[pos_x - 2][pos_y].name == "Wumpus" || cave[pos_x-3][pos_y].name == "Wumpus"){
            cout << "You hear the scream of a dying Wumpus" << endl; // if it hits, they die
            dead_wumpus(cave);
        }
        else{
            if(move < 3) // if it misses, 75% chance to move
                move_wumpus(cave);
        }
    }
    else if (x == -1 && pos_x -2 >=0){
        if(cave[pos_x -1][pos_y].name == "Wumpus" || cave[pos_x - 2][pos_y].name == "Wumpus"){
            cout << "You hear the scream of a dying Wumpus" << endl;
            dead_wumpus(cave);
        }
        else{
            if(move < 3)
                move_wumpus(cave);
        }
    }
    else if(x == -1 && pos_x - 1 >= 0){
        if(cave[pos_x-1][pos_y].name == "Wumpus"){
            cout << "You hear the scream of a dying Wumpus." << endl;
            dead_wumpus(cave);
        }
        else{
            if(move < 3)
                move_wumpus(cave);
        }
    }

    else if(x == 1 && pos_x + 3 < cave.size()){
        if(cave[pos_x + 1][pos_y].name == "Wumpus" || cave[pos_x + 2][pos_y].name == "Wumpus" || cave[pos_x + 3][pos_y].name == "Wumpus"){
            cout << "You hear the scream of a dying Wumpus" << endl; // if it hits, they die
            dead_wumpus(cave);
        }
        else{
            if(move < 3)
                move_wumpus(cave);
        }
    }
    else if (x == 1 && pos_x + 2 < cave.size()){
        if(cave[pos_x + 1][pos_y].name == "Wumpus" || cave[pos_x + 2][pos_y].name == "Wumpus"){
            cout << "You hear the scream of a dying Wumpus" << endl;
            dead_wumpus(cave);
        }
        else{
            if(move < 3)
                move_wumpus(cave);
        }
    }
    else if(x == 1 && pos_x + 1 < cave.size()){
        if(cave[pos_x + 1][pos_y].name == "Wumpus"){
            cout << "You hear the scream of a dying Wumpus." << endl;
            dead_wumpus(cave);
        }
        else{
            if(move < 3)
                move_wumpus(cave);
        }
    }
}

/************************************
** Function: fire_arrow_side
** Description: fires an arrow on the horizontal axis
** Parameters: cave, pos_x, pos_y, x, y
** Pre-conditions: all parameters exist
** Post-conditions: arrow is fired, killing/moving wumpus
*************************************/
// This function is over 20 lines (43), it all repeats the same code with minor differences
// This function could be seperated into 2, but this function is already seperated from the other arrow function
// and it wouldn't make sense to continue seperating the code only to keep the functions shorter

void fire_arrow_side(vector<vector<Room>> &cave, int pos_x, int pos_y, int x, int y){
    int move;
    cout << "You fire an arrow" << endl;
    if(y == -1 && pos_y - 3 >= 0){
        if(cave[pos_x][pos_y - 1].name == "Wumpus" || cave[pos_x][pos_y - 2].name == "Wumpus" || cave[pos_x][pos_y - 3].name == "Wumpus"){
            cout << "You hear the scream of a dying Wumpus" << endl; // if it hits, they die
            dead_wumpus(cave);
        }
        else{
            if(move < 3)   // if it misses, 75% chance to move wumpus
                move_wumpus(cave);
        }
    }
    else if (y == -1 && pos_y -2 >=0){
        if(cave[pos_x][pos_y - 1].name == "Wumpus" || cave[pos_x][pos_y - 2].name == "Wumpus"){
            cout << "You hear the scream of a dying Wumpus" << endl;
            dead_wumpus(cave);
        }
        else{
            move = rand() % 4;
                move_wumpus(cave);
        }
    }
    else if(y == -1 && pos_y - 1 >= 0){
        if(cave[pos_x][pos_y - 1].name == "Wumpus"){
            cout << "You hear the scream of a dying Wumpus." << endl;
            dead_wumpus(cave);
        }
        else{
            if(move < 3)
                move_wumpus(cave);
        }
    }

    else if(y == 1 && pos_y + 3 < cave.size()){
        if(cave[pos_x][pos_y + 1].name == "Wumpus" || cave[pos_x][pos_y + 2].name == "Wumpus" || cave[pos_x][pos_y + 3].name == "Wumpus"){
            cout << "You hear the scream of a dying Wumpus" << endl;
            dead_wumpus(cave);
        }
        else{
            if(move < 3)
                move_wumpus(cave);
        }
    }
    else if (y == 1 && pos_y + 2 < cave.size()){
        if(cave[pos_x][pos_y + 1].name == "Wumpus" || cave[pos_x][pos_y + 2].name == "Wumpus"){
            cout << "You hear the scream of a dying Wumpus" << endl;
            dead_wumpus(cave);
        }
        else{
            if(move < 3)
                move_wumpus(cave);
        }
    }
    else if(y == 1 && pos_y + 1 < cave.size()){
        if(cave[pos_x][pos_y + 1].name == "Wumpus"){
            cout << "You hear the scream of a dying Wumpus." << endl;
            dead_wumpus(cave);
        }
        else{
            if(move < 3)
                move_wumpus(cave);
        }
    }
}

/************************************
** Function: move 
** Description: moves player
** Parameters: cave, pos_x, pos_y, arrow
** Pre-conditions: all parameters exist
** Post-conditions: moves or fires an arrow
*************************************/
void move(vector<vector<Room>> &cave, int &pos_x, int &pos_y, int &arrow){
    string move = "k";
 
    getline(cin, move);

    if(move == "w" || move == "W"){ // moves up
        pos_x -= 1;
    }
    else if(move == "a" || move == "A"){ // moves left
            pos_y -= 1;
    }
    else if(move == "s" || move == "S"){ // moves down
        pos_x += 1;
    }
    else if(move == "d" || move == "D"){ // moves right
        pos_y += 1;
    }
    else if(arrow > 0 && (move == " w" || move == " W")){ // shoots arrow up
        fire_arrow(cave, pos_x, pos_y, -1, 0);
        arrow--;
    }
    else if(arrow > 0 && (move == " a" || move == " A")){ // shoots arrow left
        fire_arrow_side(cave, pos_x, pos_y, 0, -1);
        arrow--;
    }
    else if(arrow > 0 && (move == " s" || move == " S")){ // shoots arrow down
        fire_arrow(cave, pos_x, pos_y, 1, 0);
        arrow--;
    }
    else if(arrow > 0 && (move == " d" || move == " D")){ // shoots arrow right
        fire_arrow_side(cave, pos_x, pos_y, 0, 1);
        arrow--;
    }
    else if (arrow == 0 && (move == " w" || move == " W" || move == " a" || move == " A" || move == " s" || move == " S" || move == " d" || move == " D")){
        cout << "Out of arrows" << endl;
    }

}

/************************************
** Function: set_bats
** Description: places bats
** Parameters: cave
** Pre-conditions: cave exists
** Post-conditions: bats are now in the cave
*************************************/
void set_bats(vector<vector<Room>> &cave){
    Bats b1;
    Event *bptr = &b1;
    int work = 1;
    for (int i = 0; i < 2; i++){
        int x = rand() % cave.size();
        int y = rand() % cave.size();
        do{
            work = 1;
            if(cave[x][y].name == "Empty"){ // if room is empty, puts in the bats
                cave[x][y].room = bptr;
                cave[x][y].name = cave[x][y].room->name;
                work = 0;
            }
            else{    // otherwise, try again
                x = rand() % cave.size();
                y = rand() % cave.size();
            }
        }while(work == 1);
    }
}

/************************************
** Function: set_pit
** Description: places pits
** Parameters: cave
** Pre-conditions: cave exists
** Post-conditions: pits are now in the cave
*************************************/
void set_pit(vector<vector<Room>> &cave){
    Pit p1;
    Event *pptr = &p1;
    int work = 1;
    for (int i = 0; i < 2; i++){
        int x = rand() % cave.size();
        int y = rand() % cave.size();
        do{
            work = 1;
            if(cave[x][y].name == "Empty"){ // if room is empty, places pits
                cave[x][y].room = pptr;
                cave[x][y].name = cave[x][y].room->name;
                work = 0;
            }
            else{ // otherwise, try again
                x = rand() % cave.size();
                y = rand() % cave.size();
            }
        }while(work == 1);
    }
}

/************************************
** Function: set_wumpus
** Description: places wumpus
** Parameters: cave
** Pre-conditions: cave exists
** Post-conditions: wumpus is now in the cave
*************************************/
void set_wumpus(vector<vector<Room>> &cave){
    Wumpus w1;
    Event *wptr = &w1;
    int work = 1;
    int x = rand() % cave.size();
    int y = rand() % cave.size();
    do{
        work = 1;
        if(cave[x][y].name == "Empty"){ // if room is empty, places wumpus
            cave[x][y].room = wptr;
            cave[x][y].name = cave[x][y].room->name;
            work = 0;
        }
        else{ // otherwise, try again
            x = rand() % cave.size();
            y = rand() % cave.size();
        }
    }while(work == 1);
    
}

/************************************
** Function: set_gold
** Description: places gold
** Parameters: cave
** Pre-conditions: cave exists
** Post-conditions: gold is now in the cave
*************************************/
void set_gold(vector<vector<Room>> &cave){
    Gold g1;
    Event *gptr = &g1;
    int work = 1;
    int x = rand() % cave.size();
    int y = rand() % cave.size();
    do{
        work = 1;
        if(cave[x][y].name == "Empty"){ // if room is empty, places gold
            cave[x][y].room = gptr;
            cave[x][y].name = cave[x][y].room->name;
            work = 0;
        }
        else{ //otherwise, try again
            x = rand() % cave.size();
            y = rand() % cave.size();
        }
    }while(work == 1);
    
}

/************************************
** Function: set_cave
** Description: sets up the cave
** Parameters: cave, pos_x, pos_y
** Pre-conditions: all parameters exist
** Post-conditions: vector is filled with rooms
*************************************/
void set_cave(vector<vector<Room>> &cave, int pos_x, int pos_y){
    cave[pos_x][pos_y].name = "Start";
    set_bats(cave);
    set_pit(cave);
    set_wumpus(cave);
    set_gold(cave);
}

/************************************
** Function: print_debug_cave
** Description: prints cave in debug mode
** Parameters: cave, size, pos_x, pos_y
** Pre-conditions: all parameters exist
** Post-conditions: debug cave is printed
*************************************/
void print_debug_cave(vector<vector<Room>> &cave, int size, int pos_x, int pos_y){
    for (int i =0; i < size; i++){
        cout << "+-";
    }
    cout << "+" << endl;
    for (int i = 0; i < size; i++){
        for (int j = 0; j < size; j++){
            cout << "|";
            if (i == pos_x && j == pos_y)
                cout << "x";
            else if(cave[i][j].name == "Bats")
                cout << "B";
            else if(cave[i][j].name == "Pit")
                cout << "P";
            else if(cave[i][j].name == "Wumpus")
                cout << "W";
            else if(cave[i][j].name == "Gold")
                cout << "G";
            else
                cout << " ";
        }
        cout << "|";
        cout << '\n';
        for (int k =0; k < size; k++){
            cout << "+-";
        }
        cout << "+" << endl;
    }
}

/************************************
** Function: print_percept
** Description: prints percept
** Parameters: temp
** Pre-conditions: event percept exists
** Post-conditions: percept is printed 
*************************************/
void print_percept(Event &temp){
    cout << temp.percept() << endl;
}

/************************************
** Function: bat_percept
** Description: bat percept
** Parameters: cave, pos_x, pos_y
** Pre-conditions: all parameters exist
** Post-conditions: bat percept is printed
*************************************/
void bat_percept(vector<vector<Room>> &cave, int &pos_x, int &pos_y){
    Bats b1;
    Event *bptr = &b1;
        if(pos_x != cave.size() -1){
            if(cave[pos_x + 1][pos_y].name == "Bats")
                print_percept(*bptr);
        }
        if(pos_x != 0){
            if(cave[pos_x - 1][pos_y].name == "Bats")
                print_percept(*bptr);
        }
        if(pos_y != cave.size() -1){
            if(cave[pos_x][pos_y +1].name == "Bats")
                print_percept(*bptr);
        }
        if(pos_y != 0){
            if(cave[pos_x][pos_y - 1].name == "Bats")
                print_percept(*bptr);
        }
}

/************************************
** Function: pit_percept
** Description: pit_percept
** Parameters: cave, pos_x, pos_y
** Pre-conditions: all parameters exist
** Post-conditions: pit percept is printed
*************************************/
void pit_percept(vector<vector<Room>> &cave, int &pos_x, int &pos_y){
    Pit p1;
    Event *pptr = &p1;
        if(pos_x != cave.size() -1){
            if(cave[pos_x + 1][pos_y].name == "Pit")
                print_percept(*pptr);
        }
        if(pos_x != 0){
            if(cave[pos_x - 1][pos_y].name == "Pit")
                print_percept(*pptr);
        }
        if(pos_y != cave.size() -1){
            if(cave[pos_x][pos_y +1].name == "Pit")
                print_percept(*pptr);
        }
        if(pos_y != 0){
            if(cave[pos_x][pos_y - 1].name == "Pit")
                print_percept(*pptr);
        }
}

/************************************
** Function: wumpus_percept
** Description: wumpus_percept
** Parameters: cave, pos_x, pos_y
** Pre-conditions: all parameters exist
** Post-conditions: wumpus percept is printed
*************************************/
void wumpus_percept(vector<vector<Room>> &cave, int &pos_x, int &pos_y){
    Wumpus w1;
    Event *wptr = &w1;
        if(pos_x != cave.size() -1){
            if(cave[pos_x + 1][pos_y].name == "Wumpus")
                print_percept(*wptr);
        }
        if(pos_x != 0){
            if(cave[pos_x - 1][pos_y].name == "Wumpus")
                print_percept(*wptr);
        }
        if(pos_y != cave.size() -1){
            if(cave[pos_x][pos_y +1].name == "Wumpus")
                print_percept(*wptr);
        }
        if(pos_y != 0){
            if(cave[pos_x][pos_y - 1].name == "Wumpus")
                print_percept(*wptr);
        }
}

/************************************
** Function: gold_percept
** Description: gold_percept
** Parameters: cave, pos_x, pos_y
** Pre-conditions: all parameters exist
** Post-conditions: gold percept is printed
*************************************/
void gold_percept(vector<vector<Room>> &cave, int &pos_x, int &pos_y){
    Gold g1;
    Event *gptr = &g1;
        if(pos_x != cave.size() -1){
            if(cave[pos_x + 1][pos_y].name == "Gold")
                print_percept(*gptr);
        }
        if(pos_x != 0){
            if(cave[pos_x - 1][pos_y].name == "Gold")
                print_percept(*gptr);
        }
        if(pos_y != cave.size() -1){
            if(cave[pos_x][pos_y +1].name == "Gold")
                print_percept(*gptr);
        }
        if(pos_y != 0){
            if(cave[pos_x][pos_y - 1].name == "Gold")
                print_percept(*gptr);
        }
}

/************************************
** Function: percept
** Description: checks for percepts
** Parameters: cave, pos_x, pos_y
** Pre-conditions: all paremters exist
** Post-conditions: checks and prints percepts
*************************************/
void percept(vector<vector<Room>> &cave, int &pos_x, int &pos_y){
    bat_percept(cave, pos_x, pos_y);
    pit_percept(cave, pos_x, pos_y);
    gold_percept(cave, pos_x, pos_y);
    wumpus_percept(cave, pos_x, pos_y);
}

/************************************
** Function: print_event
** Description: prints_event
** Parameters: temp
** Pre-conditions: temp exists
** Post-conditions: prints event
*************************************/
void print_event(Event &temp){
    cout << temp.event() << endl;
}

/************************************
** Function: encounter
** Description: calls the event
** Parameters: cave
** Pre-conditions: cave exists
** Post-conditions: event occurs
*************************************/
int encounter(vector<vector<Room>> &cave, int &pos_x, int &pos_y, int gold){
    Bats b1;
    Event *bptr = &b1;
    Pit p1;
    Event *pptr = &p1;
    Wumpus w1;
    Event *wptr = &w1;
    Gold g1;
    Event *gptr = &g1;

    if(cave[pos_x][pos_y].name != "Empty"){
        if(cave[pos_x][pos_y].name == "Pit"){  // pit event
            print_event(*pptr);
            return 1;
        }
        else if(cave[pos_x][pos_y].name == "Bats"){ // bat event
            print_event(*bptr);
            cout << '\n';
            pos_x = rand() % cave.size();
            pos_y = rand() % cave.size();
            int temp = encounter(cave, pos_x, pos_y, gold);  // random new position, then recheck any encounters
            return temp;       
        }
        else if(cave[pos_x][pos_y].name == "Gold"){ // gold event
            print_event(*gptr);
            cave[pos_x][pos_y].name = "GEmpty";
            return 2;
        }
       else if(cave[pos_x][pos_y].name == "Wumpus"){ // wumpus event
           print_event(*wptr);
           return 1;
        }
        else if(cave[pos_x][pos_y].name == "Start" && gold == 1){ // if you reach the start with gold, you win
            return 3;
        }
    }
    return 0;

}

/************************************
** Function: print_cave
** Description: prints normal cave
** Parameters: cave, size, pos_x, pos_y
** Pre-conditions: all parameters exist
** Post-conditions: normal cave is printed
*************************************/
void print_cave(vector<vector<Room>> &cave, int size, int &pos_x, int &pos_y){
    for (int i =0; i < size; i++){
        cout << "+-";
    }
    cout << "+" << endl;
    for (int i = 0; i < size; i++){
        for (int j = 0; j < size; j++){
            cout << "|";
            if (i == pos_x && j == pos_y)
               cout << "x";
           else
            cout << " ";
        }
        cout << "|";
        cout << '\n';
        for (int k =0; k < size; k++){
            cout << "+-";
        }
        cout << "+" << endl;
    }

}

/************************************
** Function: reset_cave
** Description: resets cave
** Parameters: cave, gold, pos_x, pos_y
** Pre-conditions: all parameters exist
** Post-conditions: resets the map to the original position
*************************************/
// This function is over 20 lines (22), but is barely over it, with most of it being for loops

void reset_cave(vector<vector<Room>> &cave, int &gold, int &pos_x, int &pos_y){
    for(int i = 0; i < cave.size(); i ++){
        for (int j = 0; j < cave.size(); j++){
            if(cave[i][j].name == "GEmpty"){ // Reset empty gold pos. to gold
                cave[i][j].name = "Gold";
            }
        }
    }
    for(int i =0 ;i < cave.size(); i++){
        for(int j =0; j < cave.size(); j++){
            if(cave[i][j].name == "Dead"){ // if wumpus is dead, put a new wumpus
                cave[i][j].name = "Wumpus";
            }
        }
    }
    for(int i =0 ;i < cave.size(); i++){
        for(int j =0; j < cave.size(); j++){
            if(cave[i][j].name == "Moved"){ // if wumpus moved, delete the old wumpus, then change it to wumpus
                for(int k = 0; k < cave.size(); k ++){
                    for(int l = 0; l < cave.size(); l ++){
                        if(cave[k][l].name == "Wumpus"){
                            cave[k][l].name = "Empty";
                        }
                    }                         
                }                        
                cave[i][j].name = "Wumpus";
            }
        }
    }
    gold = 0; // reset gold
    for(int i = 0; i < cave.size(); i++){
        for(int j = 0; j < cave.size(); j++){
            if(cave[i][j].name == "Start"){ // resets starting position
                pos_x = i;
                pos_y = j;
            }
        }
    }

}

/************************************
** Function: new_cave
** Description: makes a new cave
** Parameters: cave, gold, pos_x, pos_y
** Pre-conditions: all parameters exist
** Post-conditions: a new cave is created
*************************************/
void new_cave(vector<vector<Room>> &cave, int &gold, int &pos_x, int &pos_y){
    for(int i = 0; i < cave.size(); i++){
        for(int j = 0; j < cave.size(); j++){
            cave[i][j].room = NULL;
                cave[i][j].name = "Empty"; // reset all rooms
        }
    }
    gold = 0;
    pos_x = rand() % cave.size(); // new starting position
    pos_y = rand() % cave.size();
    set_cave(cave, pos_x, pos_y); // set the new rooms
}

/************************************
** Function: game_over
** Description: asks the what to do next
** Parameters: none
** Pre-conditions: function is called
** Post-conditions: returns what user wants to do
*************************************/
int game_over(){
    int choice;
    cout << "What would you like to do?" << endl;
    cout << "(1) Play again with the same map" << endl;
    cout << "(2) Play again with a different map" << endl;
    cout << "(3) Quit" << endl;
    cin >> choice;
    return choice;
}

/************************************
** Function: debug_mode
** Description: plays game in debug_mode
** Parameters: size
** Pre-conditions: size exists
** Post-conditions: runs game in debug mode
*************************************/
// This function is over 20 lines (24), some of it could be reduced, such as by vector creation
// But it is close enough to the limit (21) without the vector creation
void debug_mode(int size){
    srand(time(NULL));
    int check = 0;
    int gold = 0;
    int new_game = 0;
    vector<vector<Room> > cave;
    int pos_x = rand() % size;
    int pos_y = rand() % size;

    cave.resize(size);
    for(int i = 0; i < size; i++){
        cave[i].resize(size);
    }
    set_cave(cave, pos_x, pos_y);
    do{    
        int arrow = 3;
        int end = 1;
        do{
            percept(cave, pos_x, pos_y);  // checks for percepts
            print_debug_cave(cave, size, pos_x, pos_y); // prints cave
            move(cave, pos_x, pos_y, arrow); // moves character
            check = encounter(cave, pos_x, pos_y, gold); // checks for encounters
            if (check == 1){
                end = 0;
                cout << "You died" << endl;
                break;
            }
            else if(check == 3){
                cout << "You win!" << endl;
                end = 0;

            }
            if (check == 2){
                gold = 1;
            }

        }while(end == 1);

        new_game = game_over();
        if(new_game == 1){
            reset_cave(cave, gold, pos_x, pos_y);
        }
        else if(new_game == 2){
            new_cave(cave, gold, pos_x, pos_y);
        }
    }while(new_game != 3);

}

/************************************
** Function: game_mode
** Description: plays game normally
** Parameters: size
** Pre-conditions: size exists
** Post-conditions: runs game normally
*************************************/
// This function is over 20 lines (24), some of it could be reduced, such as by vector creation
// But it is close enough to the limit (21) without the vector creation
void game_mode(int size){
    srand(time(NULL));
    int check = 0;
    int gold = 0;
    int new_game = 0;
    vector<vector<Room> > cave;
    int pos_x = rand() % size;
    int pos_y = rand() % size;

    cave.resize(size);
    for(int i = 0; i < size; i++){
        cave[i].resize(size);
    }
    set_cave(cave, pos_x, pos_y);
    do{    
        int arrow = 3;
        int end = 1;
        do{
            percept(cave, pos_x, pos_y);  //checks for percepts
            print_cave(cave, size, pos_x, pos_y); // prints map
            move(cave, pos_x, pos_y, arrow); // moves character
            check = encounter(cave, pos_x, pos_y, gold); // checks for encounters
            if (check == 1){
                end = 0;
                cout << "You died" << endl;
                break;
            }
            else if(check == 3){
                cout << "You win!" << endl;
                end = 0;

            }
            if (check == 2){
                gold = 1;
            }

        }while(end == 1);

        new_game = game_over();
        if(new_game == 1){
            reset_cave(cave, gold, pos_x, pos_y);
        }
        else if(new_game == 2){
            new_cave(cave, gold, pos_x, pos_y);
        }
    }while(new_game != 3);
    

}

/************************************
** Function: ai_mode
** Description: plays game with ai
** Parameters: size
** Pre-conditions: size exists
** Post-conditions: ai plays game
*************************************/
// This function is over 20 lines (24), some of it could be reduced, such as by vector creation
// But it is close enough to the limit (21) without the vector creation
void ai_mode(int size){
    srand(time(NULL));
    int check = 0;
    int gold = 0;
    int new_game = 0;
    string buffer;
    vector<vector<Room> > cave;
    int pos_x = rand() % size;
    int pos_y = rand() % size;

    cave.resize(size);
    for(int i = 0; i < size; i++){
        cave[i].resize(size);
    }
    set_cave(cave, pos_x, pos_y);
    do{    
        int arrow = 3;
        int end = 1;
        do{
            percept(cave, pos_x, pos_y);         //check for percepts
            print_cave(cave, size, pos_x, pos_y); // prints map
            ai_move(cave, pos_x, pos_y, arrow); // moves character
            check = encounter(cave, pos_x, pos_y, gold); // event occurs
            if (check == 1){
                end = 0;
                cout << "You died" << endl;
                break;
            }
            else if(check == 3){
                cout << "You win!" << endl;
                end = 0;

            }
            if (check == 2){
                gold = 1;
            }
            cout << "Press any key to continue" << endl;
            getline(cin, buffer);


        }while(end == 1);

        new_game = game_over();
        if(new_game == 1){
            reset_cave(cave, gold, pos_x, pos_y);
        }
        else if(new_game == 2){
            new_cave(cave, gold, pos_x, pos_y);
        }
    }while(new_game != 3);
    

}

/************************************
** Function: ai_move
** Description: plays a move as the ai
** Parameters: cave, pos_x, pos_y, arrow
** Pre-conditions: all parameters exist
** Post-conditions: ai moves character
*************************************/
void ai_move(vector<vector<Room>> &cave, int &pos_x, int &pos_y, int &arrow){
// This function is over 20 lines (22), but is close enough to the limit
    srand(time(NULL));
    int move = rand() % 8;

    if(move == 0 && pos_x != 0){
        pos_x -= 1;
    }
    else if(move == 1 && pos_y != 0){
            pos_y -= 1;
    }
    else if(move == 2 && pos_x != cave.size() -1){
        pos_x += 1;
    }
    else if(move == 3 && pos_y != cave.size() -1){
        pos_y += 1;
    }
    else if(arrow > 0 && (move == 4)){
        fire_arrow(cave, pos_x, pos_y, -1, 0);
        arrow--;
    }
    else if(arrow > 0 && (move == 5)){
        fire_arrow_side(cave, pos_x, pos_y, 0, -1);
        arrow--;
    }
    else if(arrow > 0 && (move == 6)){
        fire_arrow(cave, pos_x, pos_y, 1, 0);
        arrow--;
    }
    else if(arrow > 0 && (move == 7)){
        fire_arrow_side(cave, pos_x, pos_y, 0, 1);
        arrow--;
    }
    else if (arrow == 0 && (move == 5 || move == 6 || move == 7 || move == 8)){
        cout << "Out of arrows" << endl;
    }

}