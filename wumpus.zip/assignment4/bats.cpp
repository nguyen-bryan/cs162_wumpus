/************************************
** Program: bats.cpp
** Author: Bryan Nguyen
** Date: 05/23/2021
** Description: Bats Implementation
** Input: None
** Output: None
*************************************/
#include <iostream>
#include "event.h"
#include "bats.h"

using namespace std;

/************************************
** Function: Bats constructor
** Description: construction of bats
** Parameters: None
** Pre-conditions: creation of bats
** Post-conditions: bats is created
*************************************/
Bats::Bats(){
    name = "Bats";

}

/************************************
** Function: Bats deconstructor
** Description: deconstruction of bats
** Parameters: None
** Pre-conditions: decreation of bats
** Post-conditions: bats is destroyed
*************************************/
Bats::~Bats(){

}

/************************************
** Function: percept()
** Description: bats percept
** Parameters: None
** Pre-conditions: percept called
** Post-conditions: returns message
*************************************/
string Bats::percept(){
    string temp = "You hear wings flapping";
    return temp;
    
}

/************************************
** Function: event()
** Description: bats event
** Parameters: None
** Pre-conditions: event called
** Post-conditions: returns message
*************************************/
string Bats::event(){
    string temp = "A swarm of bats sweep you off to another room";
    return temp;

}
