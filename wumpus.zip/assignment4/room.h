/************************************
** Program: room.cpp
** Author: Bryan Nguyen
** Date: 05/23/2021
** Description: Room Header
** Input: None
** Output: None
*************************************/

#ifndef room_h
#define room_h

#include <iostream>

using namespace std;

class Room{ 
    private:

    public:
        Event *room;
        string name;
        
        Room();
        ~Room();
};

#endif
