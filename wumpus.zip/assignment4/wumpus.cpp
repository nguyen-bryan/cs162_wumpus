/************************************
** Program: wumpus.cpp
** Author: Bryan Nguyen
** Date: 05/23/2021
** Description: Wumpus Implementation
** Input: None
** Output: None
*************************************/

#include <iostream>
#include "event.h"
#include "wumpus.h"

using namespace std;

/************************************
** Function: Wumpus constructor
** Description: construction of Wumpus
** Parameters: None
** Pre-conditions: creation of wumpus
** Post-conditions: wumpus is created
*************************************/
Wumpus::Wumpus(){
    name = "Wumpus";

}

/************************************
** Function: Wumpus deconstructor
** Description: deconstruction of wumpus
** Parameters: None
** Pre-conditions: decreation of wumpus
** Post-conditions: wumpus is destroyed
*************************************/
Wumpus::~Wumpus(){
    
}

/************************************
** Function: percept()
** Description: wumpus percept
** Parameters: None
** Pre-conditions: percept called
** Post-conditions: returns message
*************************************/
string Wumpus::percept(){
    string temp = "You smell a terrible stench";
    return temp;
}

/************************************
** Function: event()
** Description: wumpus event
** Parameters: None
** Pre-conditions: event called
** Post-conditions: returns message
*************************************/
string Wumpus::event(){
    string temp = "You have encountered the Wumpus";
    return temp;
    
}