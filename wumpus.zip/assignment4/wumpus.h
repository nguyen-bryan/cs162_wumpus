/************************************
** Program: wumpus.h
** Author: Bryan Nguyen
** Date: 05/23/2021
** Description: Wumpus Header
** Input: None
** Output: None
*************************************/

#ifndef wumpus_h
#define wumpus_h

#include <iostream>
#include "event.h"

using namespace std;

class Wumpus : public Event{ 
    private:

    public:
        Wumpus();
        ~Wumpus();
        string percept();
        string event();
       
};

#endif
